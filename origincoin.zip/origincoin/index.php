<!doctype html>
<html lang="en">


<!-- Mirrored from templates.iqonic.design/coinex/php/ico/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Aug 2023 16:40:45 GMT -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ORIGIN - COINS</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" />
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300&amp;display=swap" rel="stylesheet">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <!-- Typography CSS -->
      <link rel="stylesheet" href="css/typography.css">
      <!-- media element player -->
      <link rel="stylesheet" type="text/css" href="css/mediaelementplayer.min.css" />
      <!-- style CSS -->
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <!-- Responsive CSS -->
      <link rel="stylesheet" type="text/css" href="css/responsive.css">
      <script src="https://kit.fontawesome.com/033428e28c.js" crossorigin="anonymous"></script> 
</head>

<body data-spy="scroll" data-offset="80">
    <!-- loading -->
    <div id="loading">
        <div id="loading-center">
            <div class='loader loader2'>
                <div>
                    <div>
                        <div>
                            <div>
                                <div>
                                    <div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- loading End -->
    <!-- Header -->
   <?php include('header.php');?> 
   <!-- Header END -->
    <!-- banner -->
    <div id="wave" class="iq-banner">
        <div class="banner-info">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 align-self-center">
                        <div class="banner-text text-left text-white">
                            <h1 class="text-white iq-mb-20">High profitable coins in future<b class="iq-font-yellow">by origin</b></h1>
                            <p>Every user knows this to after buying coins they should hold their coins for 3 months than they can sell</p>
                            <a href="https://www.youtube.com/watch?v=0O2aH4XLbto" class="button-play video-popup"><i class="fa fa-play"></i>
                                    <ion-icon name="play"></ion-icon>
                                </a>
                            <a href="javascript:void(0)" class="button bt-white iq-mt-5 iq-ml-10">How to buy and sell coins</a>
                        </div>
                    </div>
                    <div class="col-lg-5 text-center r9-mt-40">
                        <div class="iq-countdown">
                            <h2 class="iq-tw-8 iq-font-yellow"> Sell coins after</h2>
                            <ul id="countdown">
                                <li class="border-white"><span class="days">00</span>
                                    <p class="days_text ">Days</p>
                                </li>
                                <li class=" border-white"><span class="hours">00</span>
                                    <p class="hours_text">Hours</p>
                                </li>
                                <li class=" border-white"><span class="minutes">00</span>
                                    <p class="minutes_text">Minutes</p>
                                </li>
                                <li class="border-white"><span class="seconds">00</span>
                                    <p class="seconds_text">Seconds</p>
                                </li>
                            </ul>
                            <div class="iq-progress-bar-linear">
                                <p class="iq-progress-bar-text text-left">Total supply
                                    <span>50000 ORIC</span>
                                </p>
                                <div class="iq-progress-bar">
                                    <span data-percent="90"></span>
                                </div>
                            </div>
                            <a class="button iq-mb-20 bt-white" href="javascript:void(0)" role="button">Buy Token Now</a>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa-brands fa-whatsapp"></i></a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa-regular fa-envelope"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner -->
    <!-- Main-Contain -->
    <div class="main-contain">
        <!-- Clients -->
        <div class="iq-our-clients iq-ptb-60 light-bg">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12 col-md-12 ">
                        <div class="owl-carousel" data-autoplay="true" data-loop="true" data-nav="false" data-dots="false" data-items="7" data-items-laptop="6" data-items-tab="5" data-items-mobile="2" data-items-mobile-sm="1" data-margin="30">
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/01.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/02.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/03.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/04.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/05.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/06.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/01.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/02.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/03.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/04.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/05.png" alt="#"></a></div>
                            <div class="item"> <a href="clients.php"><img class="img-fluid center-block" src="images/clients/white/06.png" alt="#"></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Clients -->
        <!-- What is Ico -->
        <section id="ico" class="overview-block-pt">
            <div class="container">
                <div class="row flex-row-reverse">
                    <div class="col-lg-6 align-self-center">
                        <img src="images/about/01.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-6 align-self-center mt-5 mt-lg-0">
                        <div class="heading-title left">
                            <!-- <small class="iq-font-green">wow Awesome</small> -->
                            <h2 class="iq-tw-6">50× Return on your Invastment </h2>
                        </div>
                        <P> Here is 3 easy steps to buy and sell coins if you purchase some coins and you hold for 3 months then you can sell your coins with multiple amount of 50×</P>
                        
                        <a class="button iq-mt-20" href="javascript:void(0)" role="button">Buy coins</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- What is Ico END -->
        <!-- Our Mission -->
        <section class="overview-block-ptb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 align-self-center">
                        <img src="images/about/02.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-6 align-self-center mt-5 mt-lg-0">
                        <div class="heading-title left">
                            <!-- <small class="iq-font-green">Mission</small> -->
                            <h2 class="iq-tw-6">ORIC coin</h2>
                        </div>
                        <p> We want to become a platform that helps to peoples attracts   with us and we want a largest social media   platform so peoples could earn by doing something that helps to earn money and are available in every market soon</p>
                       
                    </div>
                </div>
            </div>
        </section>
        <!-- Our Mission END -->
        <!-- Tranding Platform -->
        <section class="iq-tranding-Platform overview-block-pt">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading-title">
                            <!-- <small class="iq-font-green">Features</small> -->
                            <h2 class="title iq-tw-6">Feature Of ORIGIN Platform</h2>
                            <!-- <p>Lorem Ipsum is simply dummy text ever sincehar the 1500s, when an unknownshil printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="light-bg">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link" id="nav-home-tab" data-bs-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">
                            <i class="la la-btc"></i><span>Shop products </span></a>
                                    <a class="nav-item nav-link active" id="nav-profile-tab" data-bs-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">
                                <i class="la la-gg-circle"></i><span>Partnership </span>
                            </a>
                                    <a class="nav-item nav-link" id="nav-app-tab" data-bs-toggle="tab" href="#nav-app" role="tab" aria-controls="nav-app" aria-selected="false">
                                <i class="la la-mobile"></i><span>Earn by watching reels</span>
                            </a>
                                    <a class="nav-item nav-link" id="nav-token-tab" data-bs-toggle="tab" href="#nav-token" role="tab" aria-controls="nav-token" aria-selected="false">
                                <i class="la la-usd"></i><span>Earn in dollars </span>
                            </a>
                                    <a class="nav-item nav-link" id="nav-contact-tab" data-bs-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">
                                <i class="la la-eur"></i><span>Support - 24×7 Support</span>
                            </a>
                                </div>
                            </nav>
                            <div class="tab-content iq-mt-50" id="nav-tabContent">
                                <div class="tab-pane fade" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img class="img-fluid" src="images/about/03.png" alt="#">
                                        </div>
                                        <div class="col-lg-6 align-self-center">
                                            <h3 class="iq-tw-6 iq-mb-15">Shop products</h3>
                                            <p>We provide the best in the category products like health care , home care, fashion care , face care, Cloths and many categories we provide with best price range of products and offers and If any user buy some products than they have a commission like 20% - 50%</p>
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade  show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img class="img-fluid" src="images/about/03.png" alt="#">
                                        </div>
                                        <div class="col-lg-6 align-self-center">
                                            <h3 class="iq-tw-6 iq-mb-15">Partnership </h3>
                                            <p>We collebs with other brand and prompt each other's Our partner's 1. To grocery 13</p>
                                          
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-app" role="tabpanel" aria-labelledby="nav-app-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img class="img-fluid" src="images/about/03.png" alt="#">
                                        </div>
                                        <div class="col-lg-6 align-self-center">
                                            <h3 class="iq-tw-6 iq-mb-15">Earn by watching reels </h3>
                                            <p>The best and impressive way to make money for users they can earn by watching reels and easily widthraw their amount</p>
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-token" role="tabpanel" aria-labelledby="nav-token-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img class="img-fluid" src="images/about/03.png" alt="#">
                                        </div>
                                        <div class="col-lg-6 align-self-center">
                                            <h3 class="iq-tw-6 iq-mb-15">Earn in dollars</h3>
                                            <p>Users have many ways to earn by using Origin platform and they received payment in dollars</p>
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <img class="img-fluid" src="images/about/03.png" alt="#">
                                        </div>
                                        <div class="col-lg-6 align-self-center">
                                            <h3 class="iq-tw-6 iq-mb-15">24×7 support</h3>
                                            <p>lokimeena133@gmail.com</p>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Tranding Platform END -->
        <!-- Product Description -->
        <!-- <section id="product" class="iq-product-description overview-block-pt">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading-title">
                            <small class="iq-font-green">Main Features</small>
                            <h2 class="title iq-tw-6">Product Description</h2>
                            <p>Lorem Ipsum is simply dummy text ever sincehar the 1500s, when an unknownshil printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
                        </div>
                    </div>
                </div>
                <div class="row iq-mt-100">
                    <div class="col-lg-4">
                        <div class="iq-fancy-box text-sm-center">
                            <div class="fancy-icon">
                                <img class="img-fluid" src="images/fancy/1.png" alt="">
                            </div>
                            <div class="fancy-content">
                                <h5 class="iq-tw-7">Professional Code</h5>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the unknown printer Lorem </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="iq-fancy-box text-sm-center">
                            <div class="fancy-icon">
                                <img class="img-fluid" src="images/fancy/2.png" alt="">
                            </div>
                            <div class="fancy-content">
                                <h5 class="iq-tw-7">Professional Code</h5>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the unknown printer Lorem </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="iq-fancy-box text-sm-center">
                            <div class="fancy-icon">
                                <img class="img-fluid" src="images/fancy/3.png" alt="">
                            </div>
                            <div class="fancy-content">
                                <h5 class="iq-tw-7">Professional Code</h5>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the unknown printer Lorem </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="iq-fancy-box text-sm-center">
                            <div class="fancy-icon">
                                <img class="img-fluid" src="images/fancy/4.png" alt="">
                            </div>
                            <div class="fancy-content">
                                <h5 class="iq-tw-7">Professional Code</h5>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the unknown printer Lorem </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="iq-fancy-box text-sm-center">
                            <div class="fancy-icon">
                                <img class="img-fluid" src="images/fancy/5.png" alt="">
                            </div>
                            <div class="fancy-content">
                                <h5 class="iq-tw-7">Professional Code</h5>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the unknown printer Lorem </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="iq-fancy-box text-sm-center">
                            <div class="fancy-icon">
                                <img class="img-fluid" src="images/fancy/6.png" alt="">
                            </div>
                            <div class="fancy-content">
                                <h5 class="iq-tw-7">Professional Code</h5>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the unknown printer Lorem </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Product Description END -->
        <!-- Tranding platform -->
       
        <!-- Token Sale Timeline -->
        <!-- Team -->
        <section id="team" class="iq-team overview-block-pb">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading-title">
                            <small class="iq-font-green"></small>
                            <h2 class="title iq-tw-6">Team Members</h2>
                            <p> We are supported by 5,000 + team mambers and 200 + collebrative agency's and tursted by 1,00,000 + peoples</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="our-team">
                            <div class="teame-2-blog">
                                <div class="team-image">
                                    <img alt="#" src="images/team/01.jpg" class="img-fluid">
                                    <ul class="social">
                                        <li><a href="https://api.whatsapp.com/send?phone=+91-8619085454" class="fa-brands fa-whatsapp"></a></li>
                                    <li><a href="https://instagram.com/lokeahmeena5454?igshid=ZGUzMzM3NWJiOQ==" class="fa-brands fa-instagram"></a></li>
                                    </ul>
                                </div>
                                <div class="team-content">
                                    <h5 class="title iq-tw-7">Lokesh kumar  meena</h5>
                                    <small class="iq-mt-5 d-block iq-mb-10 iq-font-yellow">CEO & MD</small>
                                    <p class="description">He managing every action of company and make his profitable</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                  
                    <div class="col-lg-6 col-md-6 r4-mt-40">
                        <div class="our-team">
                            <div class="team-image">
                                <img alt="#" src="images\vishal.png"class="img-fluid">
                                <ul class="social">
                                    <li><a href="https://api.whatsapp.com/send?phone=+91-9358750846" class="fa-brands fa-whatsapp"></a></li>
                                    <li><a href="https://www.instagram.com/_9inexs1nyo_official/" class="fa-brands fa-instagram"></a></li>
                                </ul>
                            </div>
                            <div class="team-content">
                                <h5 class="title iq-tw-7">Vishal Meena</h5>
                                <small class="iq-mt-5 d-block iq-mb-10 iq-font-yellow"> CO FOUNDER & CTO</small>
                                <p class="description">He managing ever backend supports and  make his profityable</p>
                            </div>
                        </div>
                    </div>
                </div>
               
                </div>
            </div>
        </section>
        <!-- Team END -->
        <!-- PARTNERS -->
      <!--   <section class="iq-partners overview-block-pb">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading-title">
                            <small class="iq-font-green">Executive Partners</small>
                            <h2 class="title iq-tw-6">Partners & Supporters</h2>
                            <p>Lorem Ipsum is simply dummy text ever sincehar the 1500s, when an unknownshil printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/01.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/02.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/03.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/04.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/05.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/06.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/06.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/05.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/04.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/05.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/06.png" alt="#">
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="Signal-partners">
                            <img class="img-fluid center-block" src="images/clients/white/01.png" alt="#">
                        </div>
                    </div>
                </div>
            </div>
        </section>
       -->  <!-- PARTNERS END -->
        <!-- FAQ -->
        <!-- <section id="faq" class="iq-anything overview-block-pb">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading-title">
                            <small class="iq-font-green">Ask Anything</small>
                            <h2 class="title iq-tw-6">Frequently Asked Questions</h2>
                            <p>Lorem Ipsum is simply dummy text ever sincehar the 1500s, when an unknownshil printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 align-self-center mt-5 mt-lg-0">
                        <iframe class="anything-video" src="https://www.youtube.com/embed/d95RnJorlQ4?rel=0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                    <div class="col-lg-6 r9-mt-40">
                        <div class="iq-accordion">
                            <div class="iq-ad-block ad-active"> <a href="javascript:void(0)" class="ad-title iq-tw-6">Ipsum is simply dummy the printing?</a>
                                <div class="ad-details">It has survived not only five centuries, but also the leap into electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.</div>
                            </div>
                            <div class="iq-ad-block"> <a href="javascript:void(0)" class="ad-title iq-tw-6">Dummy the printing and type setting?</a>
                                <div class="ad-details">It has survived not only five centuries, but also the leap into electronic typesetting. It has survived not only five centuries, but also the leap into electronic typesetting.</div>
                            </div>
                            <div class="iq-ad-block"> <a href="javascript:void(0)" class="ad-title iq-tw-6">Standard dummy since the 1500s?</a>
                                <div class="ad-details">It has survived not only five centuries, but also the leap into electronic typesetting. It has survived not only five centuries, but also the leap into electronic typesetting.</div>
                            </div>
                            <div class="iq-ad-block"> <a href="javascript:void(0)" class="ad-title iq-tw-6">It has survived five centuries?</a>
                                <div class="ad-details">It has survived not only five centuries, but also the leap into electronic typesetting. It has survived not only five centuries, but also the leap into electronic typesetting.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- FAQ END -->
        <!-- Our Blog -->
       <!-- <section class="overview-block-ptb blog-style">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading-title">
                            <small class="iq-font-green">News</small>
                            <h2 class="title iq-tw-6">Our Blog</h2>
                            <p>Lorem Ipsum is simply dummy text ever sincehar the 1500s, when an unknownshil printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="owl-carousel" data-autoplay="true" data-loop="true" data-nav="true" data-dots="false" data-items="3" data-items-laptop="3" data-items-tab="2" data-items-mobile="1" data-items-mobile-sm="1" data-margin="30">
                            <div class="item">
                                <div class="iq-blog-box">
                                    <div class="iq-blog-image clearfix">
                                        <div class="media-wrapper">
                                            <video style="width:100%;height:100%;" id="player1" poster="video/01.jpg" controls preload="none">
                                                <source type="video/m4v" src="video/01.php" />
                                                <source type="video/webm" src="video/01.webm" />
                                                <source type="video/ogg" src="video/01.ogv" />
                                            </video>
                                        </div>
                                    </div>
                                    <div class="iq-blog-detail">
                                        <div class="blog-title"> <a href="blog-single.php"><h5 class="iq-tw-7 iq-mb-10">Blogpost With php Video</h5> </a> </div>
                                        <div class="blog-content">
                                            <p>Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                                        </div>
                                        <div class="iq-blog-meta">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-user-circle" aria-hidden="true"></i> Tom Herry</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i> 12 Aug 2017</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> 5</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="iq-blog-box">
                                    <div class="iq-blog-image clearfix">
                                        <img class="img-fluid center-block" src="images/blog/01.jpg" alt="#">
                                    </div>
                                    <div class="iq-blog-detail">
                                        <div class="blog-title"> <a href="blog-single.php"><h5 class="iq-tw-7 iq-mb-10">Blogpost With Image</h5> </a> </div>
                                        <div class="blog-content">
                                            <p>Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                                        </div>
                                        <div class="iq-blog-meta">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-user-circle" aria-hidden="true"></i> Tom Herry</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i> 12 Aug 2017</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> 5</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="iq-blog-box">
                                    <div class="iq-blog-image clearfix">
                                        <div class="iq-bolg-video">
                                            <iframe src="https://player.vimeo.com/video/176916362"></iframe>
                                        </div>
                                    </div>
                                    <div class="iq-blog-detail">
                                        <div class="blog-title"> <a href="blog-single.php"><h5 class="iq-tw-7 iq-mb-10">Blogpost With Vimeo</h5> </a> </div>
                                        <div class="blog-content">
                                            <p>Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                                        </div>
                                        <div class="iq-blog-meta">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-user-circle" aria-hidden="true"></i> Tom Herry</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i> 12 Aug 2017</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> 5</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                             <div class="item">
                                <div class="iq-blog-box">
                                    <div class="iq-blog-image clearfix">
                                        <div class="iq-bolg-video">
                                            <iframe src="https://www.youtube.com/embed/nrJtHemSPW4?rel=0" allowfullscreen></iframe>
                                        </div>
                                    </div>
                                    <div class="iq-blog-detail">
                                        <div class="blog-title"> <a href="blog-single.php"><h5 class="iq-tw-7 iq-mb-10">Blogpost With Youtube</h5> </a> </div>
                                        <div class="blog-content">
                                            <p>Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                                        </div>
                                        <div class="iq-blog-meta">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-user-circle" aria-hidden="true"></i> Tom Herry</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i> 12 Aug 2017</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> 5</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="iq-blog-box">
                                    <div class="iq-blog-image clearfix">
                                        <img class="img-fluid center-block" src="images/blog/03.jpg" alt="#">
                                        <div class="players" id="player2-container">
                                            <div class="media-wrapper">
                                                <audio id="player2" preload="none" controls>
                                                    <source src="http://www.largesound.com/ashborytour/sound/AshboryBYU.mp3" type="audio/mp3">
                                                </audio>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="iq-blog-detail">
                                        <div class="blog-title"> <a href="blog-single.php"><h5 class="iq-tw-7 iq-mb-10">Blogpost With Audio</h5> </a> </div>
                                        <div class="blog-content">
                                            <p>Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                                        </div>
                                        <div class="iq-blog-meta">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-user-circle" aria-hidden="true"></i> Tom Herry</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i> 12 Aug 2017</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> 5</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="iq-blog-box">
                                    <div class="iq-blog-image clearfix">
                                        <img class="img-fluid center-block" src="images/blog/02.jpg" alt="#">
                                    </div>
                                    <div class="iq-blog-detail">
                                        <div class="blog-title"> <a href="blog-single.php"><h5 class="iq-tw-7 iq-mb-10">Blogpost With Image</h5> </a> </div>
                                        <div class="blog-content">
                                            <p>Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                                        </div>
                                        <div class="iq-blog-meta">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-user-circle" aria-hidden="true"></i> Tom Herry</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i> 12 Aug 2017</a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> 5</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Our Blog END -->
    </div>
    <!-- Token Sale Proceeds -->
    <!-- <section id="contact-us" class="contact-us overview-block-pt">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <form id="contact" method="post">
                        <div class="heading-title left">
                            <small class="iq-font-green">Contact With Us</small>
                            <h2 class="title iq-tw-6">Contact ICO CoinEX</h2>
                        </div>
                        <p class="iq-mb-30">Quae laboriosam sunt consectetur, assumenda provident lorem ipsum dolor sit amet, consectetur adipisicing elit. hic perspiciatis.</p>
                        <div class="contact-form">
                            <div class="section-field">
                                <input class="require" id="contact_name" type="text" placeholder="Name*" name="name">
                            </div>
                            <div class="section-field">
                                <input class="require" id="contact_email" type="email" placeholder="Email*" name="email">
                            </div>
                            <div class="section-field">
                                <input class="require" id="contact_phone" type="text" placeholder="Phone*" name="phone">
                            </div>
                            <div class="section-field textarea">
                                <textarea id="contact_message" class="input-message require" placeholder="Comment*" rows="5" name="message"></textarea>
                            </div>
                            <div class="section-field iq-mt-20">
                                <div class="g-recaptcha" data-sitekey="6Lc5XV4UAAAAAJzUmGomye9Peru8lXyzT22FH0lX"></div>
                            </div>
                            <div class="d-block text-center">
                                <button id="submit" name="submit" type="submit" value="Send" class="button iq-mt-15">Send Message</button>
                            </div>
                            <div class="alert alert-success alert-dismissible fade show" role="alert" id="success">
                                <strong>Thank You, Your message has been received.</strong>.
                                <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-lg-6 iq-pl-50">
                    <div class="heading-title left iq-mt-30">
                        <small class="iq-font-green">JUST ONE CALLs</small>
                        <h2 class="title iq-tw-6">Address</h2>
                    </div>
                    <p>It has survived not only five centuries, but also the leap into electronic typesetting. It has survived not only five centuries.</p>
                    <div class="iq-contact-box-01 iq-mt-40">
                        <div class="iq-icon yellow-bg">
                            <i aria-hidden="true" class="la la-map-marker"></i>
                        </div>
                        <div class="contact-content">
                            <h5 class="iq-tw-7">Address</h5>
                            <span class="lead">1234 North Luke Lane,<br>South Bend,IN 360001</span>
                        </div>
                    </div>
                    <div class="iq-contact-box-01 iq-mt-40">
                        <div class="iq-icon yellow-bg">
                            <i aria-hidden="true" class="la la-phone-square"></i>
                        </div>
                        <div class="contact-content">
                            <h5 class="iq-tw-6">Phone</h5>
                            <span class="lead iq-tw-6">+0123 456 789</span>
                            <p class="iq-mb-0">Mon-Fri 8:00am - 8:00pm</p>
                        </div>
                    </div>
                    <div class="iq-contact-box-01 iq-mt-40">
                        <div class="iq-icon yellow-bg">
                            <i aria-hidden="true" class="la la-envelope-o"></i>
                        </div>
                        <div class="contact-content">
                            <h5 class="iq-tw-6">Mail</h5>
                            <span class="lead iq-tw-6">support@coinex.com</span>
                            <p class="iq-mb-0">24 X 7 online support</p>
                        </div>
                    </div>
                    <ul class="info-share">
                        <li><a href="javascript:void(0)"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-pinterest"></i></a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-google"></i></a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-github"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="copyright-box text-center iq-bg-over iq-over-black-20 text-center iq-ptb-20 iq-mt-100">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="iq-copyright text-white">© Copyright 2023 CoinEX Developed by <a href="https://iqonic.design/" target="_blank">iqonicdesign.</a></div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Token Sale Proceeds END -->
   
<div class="modal fade iq-login" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content blue-bg">
            <div class="modal-header text-center">
                <h4 class="modal-title ">Login</h4>
                <button type="button" class="btn-close bg-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="contact-form">
                    <div class="section-field">
                        <input class="require" id="contact_name" type="text" placeholder="Name*" name="name">
                    </div>
                    <div class="section-field">
                        <input class="require" id="contact_email" type="email" placeholder="Email*" name="email">
                    </div>
                    <a class="button iq-mtb-10" href="javascript:void(0)">Sign In</a>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input">Remember Me</label>
                            </div>
                        </div>
                        <div class="col-sm-6 text-end">
                            <a href="javascript:void(0)">Forgot Password</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <div> Don't Have an Account? <a href="javascript:void(0)" class="iq-font-yellow">Register Now</a></div>
                <ul class="iq-media-blog iq-mt-20">
                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                    <li><a href="# "><i class="fa fa-google "></i></a></li>
                    <li><a href="# "><i class="fa fa-github "></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
    <!-- back-to-top -->
    <div id="back-to-top">
        <a class="top" id="top" href="#top"><i class="fa fa-angle-double-up" aria-hidden="true"></i> </a>
    </div>
    <!-- back-to-top End -->
    <!-- bubbly -->
    <canvas id="canvas1"></canvas>
    <!-- bubbly End -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-min.js"></script>
    <!-- popper JavaScript -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All-plugins JavaScript -->
    <script src="js/all-plugins.js"></script>
    <!-- timeline JavaScript -->
    <script src="js/timeline.min.js"></script>
    <!-- wave JavaScript -->
    <script src='js/wave/three.min.js'></script>
    <script src='js/wave/Projector.js'></script>
    <script src='js/wave/CanvasRenderer.js'></script>
    <script src="js/wave/index.js"></script>
    <!-- bubbly JavaScript -->
    <script src="js/bubbly-bg.js"></script>
    <!-- amcharts -->
    <script src="js/amcharts/amcharts.js"></script>
    <script src="js/amcharts/serial.js"></script>
    <script src="js/amcharts/export.min.js"></script>
    <script src="js/amcharts/none.js"></script>
    <!-- carousel JavaScript -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="js/custom.js"></script>
</body>


<!-- Mirrored from templates.iqonic.design/coinex/php/ico/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Aug 2023 16:40:59 GMT -->
</html>