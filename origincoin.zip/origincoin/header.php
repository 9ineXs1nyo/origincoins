 <header>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="index.php">
                                <img src="images/logo.png" class="img-fluid" alt="">
                            </a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="la la-bars"></i>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto w-100 justify-content-end">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#wave">Dashboard </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#ico">Origin coin payment details </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#product">Profile</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#token">Raffer a ferind</a>
                                </li>
                              
                            </ul>
                        </div>
                        <ul class="nav justify-content-end">
                         
                            <li class="nav-item iq-mlr-0">
                                <a class="nav-link button"   href="javascript:void(0)">Login</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
   