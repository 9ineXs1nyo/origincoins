<!doctype html>
<html lang="en">


<!-- Mirrored from templates.iqonic.design/coinex/php/ico/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Aug 2023 16:40:45 GMT -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ORIGIN - COINS LOIGN</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" />
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300&amp;display=swap" rel="stylesheet">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <!-- Typography CSS -->
      <link rel="stylesheet" href="css/typography.css">
      <!-- media element player -->
      <link rel="stylesheet" type="text/css" href="css/mediaelementplayer.min.css" />
      <!-- style CSS -->
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <!-- Responsive CSS -->
      <link rel="stylesheet" type="text/css" href="css/responsive.css">
      <script src="https://kit.fontawesome.com/033428e28c.js" crossorigin="anonymous"></script> 
</head>

<body data-spy="scroll" data-offset="80">
    <!-- loading -->
    <div id="loading">
        <div id="loading-center">
            <div class='loader loader2'>
                <div>
                    <div>
                        <div>
                            <div>
                                <div>
                                    <div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- loading End -->
    <!-- Header -->
   <?php include('header.php');?> 
   <!-- Header END -->
    <!-- banner -->

   
<div class="modal fade iq-login">
    <div class="modal-dialog" role="document">
        <div class="modal-content blue-bg">
            <div class="modal-header text-center">
                <h4 class="modal-title ">Login</h4>
                <button type="button" class="btn-close bg-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="contact-form">
                    <div class="section-field">
                        <input class="require" id="contact_name" type="text" placeholder="Name*" name="name">
                    </div>
                    <div class="section-field">
                        <input class="require" id="contact_email" type="email" placeholder="Email*" name="email">
                    </div>
                    <a class="button iq-mtb-10" href="javascript:void(0)">Sign In</a>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input">Remember Me</label>
                            </div>
                        </div>
                        <div class="col-sm-6 text-end">
                            <a href="javascript:void(0)">Forgot Password</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <div> Don't Have an Account? <a href="javascript:void(0)" class="iq-font-yellow">Register Now</a></div>
                <ul class="iq-media-blog iq-mt-20">
                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                    <li><a href="# "><i class="fa fa-google "></i></a></li>
                    <li><a href="# "><i class="fa fa-github "></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
    <!-- back-to-top -->
    <div id="back-to-top">
        <a class="top" id="top" href="#top"><i class="fa fa-angle-double-up" aria-hidden="true"></i> </a>
    </div>
    <!-- back-to-top End -->
    <!-- bubbly -->
    <canvas id="canvas1"></canvas>
    <!-- bubbly End -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-min.js"></script>
    <!-- popper JavaScript -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All-plugins JavaScript -->
    <script src="js/all-plugins.js"></script>
    <!-- timeline JavaScript -->
    <script src="js/timeline.min.js"></script>
    <!-- wave JavaScript -->
    <script src='js/wave/three.min.js'></script>
    <script src='js/wave/Projector.js'></script>
    <script src='js/wave/CanvasRenderer.js'></script>
    <script src="js/wave/index.js"></script>
    <!-- bubbly JavaScript -->
    <script src="js/bubbly-bg.js"></script>
    <!-- amcharts -->
    <script src="js/amcharts/amcharts.js"></script>
    <script src="js/amcharts/serial.js"></script>
    <script src="js/amcharts/export.min.js"></script>
    <script src="js/amcharts/none.js"></script>
    <!-- carousel JavaScript -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="js/custom.js"></script>
</body>


<!-- Mirrored from templates.iqonic.design/coinex/php/ico/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Aug 2023 16:40:59 GMT -->
</html>